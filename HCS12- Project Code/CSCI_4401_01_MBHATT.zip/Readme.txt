Compiling MPI

mpicc Cfile.c -o exec

running MPI

mpirun -np numOfProcess '-o filehere' SIZEofMATRIXhere



Compiling and Running Java:

javac *.java

java matrixmul



By Manish Bhatt
   Principles of Operating Systems

Also recommend TEXTPAD or something like that to open the output.txt file. 
   